from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from core.models import Booking, Review, Payment
from freelancers.models import FreelancerProfile
from freelancers.forms import FreelancerProfileForm, ServiceForm, AvailabilityForm
from django.db.models import Sum
from datetime import date
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import FreelancerProfileForm, ServiceForm, AvailabilityForm
from .models import FreelancerProfile, FreelancerService
from freelancers.models import FreelancerService
from django.utils import timezone
@login_required
def add_service(request):
    if request.method == 'POST':
        form = ServiceForm(request.POST)
        if form.is_valid():
            service = form.save(commit=False)
            service.freelancer = request.user
            service.is_approved = False
            service.save()
            messages.success(request, 'Your service has been submitted for approval.')
            return redirect('freelancer_dashboard')
    else:
        form = ServiceForm()
    
    return render(request, 'freelancers/add_service.html', {
        'form': form,
    })

@login_required
def freelancer_dashboard(request):
    if request.user.user_type != 'freelancer':
        return redirect('profile_redirect')
    
    try:
        profile = request.user.freelancerprofile
    except FreelancerProfile.DoesNotExist:
        profile = FreelancerProfile.objects.create(user=request.user)
    
    upcoming_bookings = Booking.objects.filter(
        freelancer=request.user,
        status__in=['confirmed', 'pending'],
        start_date__gte=date.today()
    ).order_by('start_date')[:5]
    
    # Calculate total earnings from completed payments
    total_earnings = Payment.objects.filter(
        booking__freelancer=request.user,
        status='completed'
    ).aggregate(Sum('amount'))['amount__sum'] or 0
    
    services = FreelancerService.objects.filter(freelancer=request.user)
    
    return render(request, 'freelancers/dashboard.html', {
        'profile': profile,
        'upcoming_bookings': upcoming_bookings,
        'total_earnings': total_earnings,
        'services': services,
    })

@login_required
def manage_profile(request):
    try:
        profile = request.user.freelancerprofile
    except FreelancerProfile.DoesNotExist:
        profile = FreelancerProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = FreelancerProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated.')
            return redirect('freelancer_dashboard')
    else:
        form = FreelancerProfileForm(instance=profile)
    
    return render(request, 'freelancers/manage_profile.html', {
        'form': form,
    })

@login_required
def respond_booking(request, booking_id, action):
    booking = get_object_or_404(Booking, id=booking_id, freelancer=request.user, status='pending')
    
    if action == 'accept':
        booking.status = 'confirmed'
        booking.save()
        messages.success(request, 'You have accepted the booking request.')
    elif action == 'decline':
        booking.status = 'cancelled'
        booking.save()
        messages.success(request, 'You have declined the booking request.')
    
    return redirect('freelancer_bookings')

@login_required
def update_availability(request):
    services = FreelancerService.objects.filter(freelancer=request.user)
    
    if request.method == 'POST':
        form = AvailabilityForm(request.POST)
        if form.is_valid():
            for service in services:
                service.is_available = form.cleaned_data['availability']
                service.save()
            messages.success(request, 'Your availability has been updated.')
            return redirect('freelancer_dashboard')
    else:
        initial_availability = services.first().is_available if services.exists() else True
        form = AvailabilityForm(initial={'availability': initial_availability})
    
    return render(request, 'freelancers/update_availability.html', {
        'form': form,
    })

@login_required
def receive_payment(request):
    payments = Payment.objects.filter(
        booking__freelancer=request.user
    ).order_by('-created_at')
    
    return render(request, 'freelancers/receive_payment.html', {
        'payments': payments,
    })

@login_required
def track_earnings(request):
    payments = Payment.objects.filter(
        booking__freelancer=request.user,
        status='completed'
    ).order_by('-created_at')
    
    total_earnings = payments.aggregate(Sum('amount'))['amount__sum'] or 0
    
    return render(request, 'freelancers/track_earnings.html', {
        'payments': payments,
        'total_earnings': total_earnings,
    })

from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages

@login_required
def freelancer_bookings(request):
    now = timezone.now()
    
    # Get all bookings for the freelancer
    bookings = Booking.objects.filter(freelancer=request.user).order_by('-created_at')
    
    # Filter by status and date conditions
    upcoming_bookings = bookings.filter(
        status='confirmed',
        start_date__gt=now  # Only future bookings
    )
    
    pending_bookings = bookings.filter(status='pending')
    
    completed_bookings = bookings.filter(
        status='completed'
    )
    
    cancelled_bookings = bookings.filter(status='cancelled')
    
    return render(request, 'freelancers/bookings.html', {
        'upcoming_bookings': upcoming_bookings,
        'pending_bookings': pending_bookings,
        'completed_bookings': completed_bookings,
        'cancelled_bookings': cancelled_bookings,
    })

@login_required
def accept_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, freelancer=request.user)
    if booking.status == 'pending':
        booking.status = 'confirmed'
        booking.save()
        messages.success(request, 'Booking has been accepted and moved to Upcoming.')
    return redirect('freelancer_bookings')

@login_required
def complete_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, freelancer=request.user)
    if booking.status == 'confirmed':
        booking.status = 'completed'
        booking.save()
        messages.success(request, 'Booking marked as completed.')
    return redirect('freelancer_bookings')

@login_required
def reject_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, freelancer=request.user)
    if booking.status == 'pending':
        booking.status = 'cancelled'
        booking.save()
        messages.success(request, 'Booking has been rejected and moved to Cancelled.')
    return redirect('freelancer_bookings')

@login_required
def suspend_service(request, service_id):
    service = get_object_or_404(FreelancerService, id=service_id, freelancer=request.user)
    service.is_available = not service.is_available
    service.save()
    
    action = "suspended" if not service.is_available else "activated"
    messages.success(request, f'Service has been {action}.')
    return redirect('freelancer_dashboard')

@login_required
def display_reviews(request):
    reviews = Review.objects.filter(freelancer=request.user, is_approved=True).order_by('-created_at')
    return render(request, 'freelancers/reviews.html', {
        'reviews': reviews,
    })
