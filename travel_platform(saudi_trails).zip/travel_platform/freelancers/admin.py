from django.contrib import admin
from .models import FreelancerProfile, FreelancerService

class FreelancerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'experience', 'languages')
    search_fields = ('user__username', 'skills')

class FreelancerServiceAdmin(admin.ModelAdmin):
    list_display = ('freelancer', 'service_type', 'title', 'price')
    list_filter = ('service_type', 'is_available')
    search_fields = ('title', 'description')

admin.site.register(FreelancerProfile, FreelancerProfileAdmin)
admin.site.register(FreelancerService, FreelancerServiceAdmin)