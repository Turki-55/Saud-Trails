from django import forms
from freelancers.models import FreelancerProfile
from django import forms
from .models import FreelancerProfile
from freelancers.models import FreelancerService


class FreelancerProfileForm(forms.ModelForm):
    class Meta:
        model = FreelancerProfile
        fields = ['bio', 'skills', 'experience', 'languages', 'profile_picture']  # Update this line
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4}),
            'skills': forms.Textarea(attrs={'rows': 3}),
        }
class ServiceForm(forms.ModelForm):
    class Meta:
        model = FreelancerService
        fields = ['service_type', 'title', 'description', 'price']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class AvailabilityForm(forms.Form):
    availability = forms.BooleanField(
        required=False,
        label='Make all my services available for booking'
    )