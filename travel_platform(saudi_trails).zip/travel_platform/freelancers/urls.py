from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.freelancer_dashboard, name='freelancer_dashboard'),
    path('manage-profile/', views.manage_profile, name='manage_profile'),
    path('respond-booking/<int:booking_id>/<str:action>/', views.respond_booking, name='respond_booking'),
    path('update-availability/', views.update_availability, name='update_availability'),
    path('receive-payment/', views.receive_payment, name='receive_payment'),
    path('track-earnings/', views.track_earnings, name='track_earnings'),
    path('add-service/', views.add_service, name='add_service'),
    path('bookings/', views.freelancer_bookings, name='freelancer_bookings'),
    path('suspend-service/<int:service_id>/', views.suspend_service, name='suspend_service'),
    path('reviews/', views.display_reviews, name='freelancer_reviews'),
    path('bookings/<int:booking_id>/accept/', views.accept_booking, name='accept_booking'),
    path('bookings/<int:booking_id>/reject/', views.reject_booking, name='reject_booking'),
    path('bookings/<int:booking_id>/complete/', views.complete_booking, name='complete_booking'),

]