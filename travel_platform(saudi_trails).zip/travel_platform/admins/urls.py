from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('add-destination/', views.add_destination, name='add_destination'),
    path('add-event/', views.add_event, name='add_event'),
    path('manage-reviews/', views.manage_reviews, name='manage_reviews'),
    path('approve-review/<int:review_id>/<str:action>/', views.approve_review, name='approve_review'),
    path('delete-user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('approve-refund/<int:refund_id>/<str:action>/', views.approve_refund, name='approve_refund'),
    path('handle-suggestion/<int:destination_id>/<str:action>/', views.handle_suggestion, name='handle_suggestion'),
    path('monitor-payment/', views.monitor_payment, name='monitor_payment'),
    path('manage-booking/', views.manage_booking, name='manage_booking'),
    path('send-email/', views.send_email_notification, name='send_email_notification'),
    path('suspend-service/<int:service_id>/', views.suspend_service_admin, name='suspend_service_admin'),
    path('customer-support/', views.customer_support, name='customer_support'),
    path('update-ticket/<int:ticket_id>/<str:status>/', views.update_ticket_status, name='update_ticket_status'),
    path('manage-profile/', views.manage_profile, name='manage_profile'),
    path('destinations/', views.admin_destinations, name='admin_destinations'),
    path('events/', views.admin_events, name='admin_events'),
    path('refunds/', views.admin_refunds, name='admin_refunds'),
    path('suggestions/', views.admin_suggestions, name='admin_suggestions'),
    path('services/', views.admin_services, name='admin_services'),
    path('users/', views.admin_users, name='admin_users'),
]