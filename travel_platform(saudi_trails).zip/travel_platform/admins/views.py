from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from core.models import Destination, Event, Review, User, Booking, RefundRequest, SupportTicket, Payment
from admins.models import AdminProfile
from admins.forms import DestinationForm, EventForm, AdminProfileForm
from django.db.models import Count, Q
from freelancers.models import FreelancerService


def admin_check(user):
    return user.user_type == 'admin'

@login_required
@user_passes_test(admin_check)
def admin_dashboard(request):
    try:
        profile = request.user.adminprofile
    except AdminProfile.DoesNotExist:
        profile = AdminProfile.objects.create(user=request.user)
    
    pending_destinations = Destination.objects.filter(is_approved=False).count()
    pending_services = FreelancerService.objects.filter(is_approved=False).count()
    pending_refunds = RefundRequest.objects.filter(status='pending').count()
    open_tickets = SupportTicket.objects.filter(status='open').count()
    
    return render(request, 'admins/dashboard.html', {
        'profile': profile,
        'pending_destinations': pending_destinations,
        'pending_services': pending_services,
        'pending_refunds': pending_refunds,
        'open_tickets': open_tickets,
    })

@login_required
@user_passes_test(admin_check)
def add_destination(request):
    if request.method == 'POST':
        form = DestinationForm(request.POST, request.FILES)
        if form.is_valid():
            destination = form.save(commit=False)
            destination.is_approved = True
            destination.save()
            messages.success(request, 'Destination has been added successfully.')
            return redirect('admin_dashboard')
    else:
        form = DestinationForm()
    
    return render(request, 'admins/add_destination.html', {
        'form': form,
    })

@login_required
@user_passes_test(admin_check)
def add_event(request):
    if request.method == 'POST':
        form = EventForm(request.POST)
        if form.is_valid():
            event = form.save(commit=False)
            event.created_by = request.user
            event.save()
            messages.success(request, 'Event has been added successfully.')
            return redirect('admin_dashboard')
    else:
        form = EventForm()
    
    return render(request, 'admins/add_event.html', {
        'form': form,
    })

@login_required
@user_passes_test(admin_check)
def manage_reviews(request):
    reviews = Review.objects.filter(is_approved=False).order_by('-created_at')
    return render(request, 'admins/manage_reviews.html', {
        'reviews': reviews,
    })

@login_required
@user_passes_test(admin_check)
def approve_review(request, review_id, action):
    review = get_object_or_404(Review, id=review_id)
    
    if action == 'approve':
        review.is_approved = True
        review.save()
        messages.success(request, 'Review has been approved.')
    elif action == 'reject':
        review.delete()
        messages.success(request, 'Review has been rejected.')
    
    return redirect('manage_reviews')

@login_required
@user_passes_test(admin_check)
def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        username = user.username
        user.delete()
        messages.success(request, f'User {username} has been deleted.')
        return redirect('admin_dashboard')
    
    return render(request, 'admins/confirm_delete_user.html', {
        'user': user,
    })

@login_required
@user_passes_test(admin_check)
def approve_refund(request, refund_id, action):
    refund = get_object_or_404(RefundRequest, id=refund_id)
    
    if action == 'approve':
        refund.status = 'approved'
        refund.save()
        
        # In a real app, this would trigger the actual refund process
        refund.booking.status = 'cancelled'
        refund.booking.save()
        
        messages.success(request, 'Refund has been approved.')
    elif action == 'reject':
        refund.status = 'rejected'
        refund.save()
        messages.success(request, 'Refund has been rejected.')
    
    return redirect('admin_refunds')

@login_required
@user_passes_test(admin_check)
def handle_suggestion(request, destination_id, action):
    destination = get_object_or_404(Destination, id=destination_id, is_approved=False)
    
    if action == 'approve':
        destination.is_approved = True
        destination.save()
        
        # Add loyalty points to the suggester
        if destination.suggested_by:
            destination.suggested_by.loyalty_points += 50  # 50 points for suggestion
            destination.suggested_by.save()
        
        messages.success(request, 'Destination suggestion has been approved.')
    elif action == 'reject':
        destination.delete()
        messages.success(request, 'Destination suggestion has been rejected.')
    
    return redirect('admin_suggestions')

@login_required
@user_passes_test(admin_check)
def monitor_payment(request):
    payments = Payment.objects.all().order_by('-created_at')
    return render(request, 'admins/monitor_payment.html', {
        'payments': payments,
    })

@login_required
@user_passes_test(admin_check)
def manage_booking(request):
    bookings = Booking.objects.all().order_by('-created_at')
    return render(request, 'admins/manage_booking.html', {
        'bookings': bookings,
    })

@login_required
@user_passes_test(admin_check)
def send_email_notification(request):
    if request.method == 'POST':
        # In a real app, this would send actual emails
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        recipient_type = request.POST.get('recipient_type')
        
        if recipient_type == 'all':
            count = User.objects.count()
        elif recipient_type == 'tourists':
            count = User.objects.filter(user_type='tourist').count()
        elif recipient_type == 'freelancers':
            count = User.objects.filter(user_type='freelancer').count()
        else:
            count = 0
        
        messages.success(request, f'Email notification "{subject}" has been sent to {count} users.')
        return redirect('admin_dashboard')
    
    return render(request, 'admins/send_email_notification.html')

@login_required
@user_passes_test(admin_check)
def suspend_service_admin(request, service_id):
    service = get_object_or_404(FreelancerService, id=service_id)
    service.is_available = not service.is_available
    service.save()
    
    action = "suspended" if not service.is_available else "activated"
    messages.success(request, f'Service has been {action}.')
    return redirect('admin_services')

@login_required
@user_passes_test(admin_check)
def customer_support(request):
    tickets = SupportTicket.objects.all().order_by('-created_at')
    return render(request, 'admins/customer_support.html', {
        'tickets': tickets,
    })

@login_required
@user_passes_test(admin_check)
def update_ticket_status(request, ticket_id, status):
    ticket = get_object_or_404(SupportTicket, id=ticket_id)
    ticket.status = status
    ticket.save()
    messages.success(request, f'Ticket status has been updated to {status}.')
    return redirect('customer_support')

@login_required
@user_passes_test(admin_check)
def manage_profile(request):
    try:
        profile = request.user.adminprofile
    except AdminProfile.DoesNotExist:
        profile = AdminProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = AdminProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated.')
            return redirect('admin_dashboard')
    else:
        form = AdminProfileForm(instance=profile)
    
    return render(request, 'admins/manage_profile.html', {
        'form': form,
    })

@login_required
@user_passes_test(admin_check)
def admin_destinations(request):
    destinations = Destination.objects.all().order_by('-created_at')
    return render(request, 'admins/admin_destinations.html', {
        'destinations': destinations,
    })

@login_required
@user_passes_test(admin_check)
def admin_events(request):
    events = Event.objects.all().order_by('-created_at')
    return render(request, 'admins/admin_events.html', {
        'events': events,
    })

@login_required
@user_passes_test(admin_check)
def admin_refunds(request):
    refunds = RefundRequest.objects.all().order_by('-created_at')
    return render(request, 'admins/admin_refunds.html', {
        'refunds': refunds,
    })

@login_required
@user_passes_test(admin_check)
def admin_suggestions(request):
    suggestions = Destination.objects.filter(is_approved=False).order_by('-created_at')
    return render(request, 'admins/admin_suggestions.html', {
        'suggestions': suggestions,
    })

@login_required
@user_passes_test(admin_check)
def admin_services(request):
    services = FreelancerService.objects.all().order_by('-created_at')
    return render(request, 'admins/admin_services.html', {
        'services': services,
    })

@login_required
@user_passes_test(admin_check)
def admin_users(request):
    users = User.objects.all().order_by('-date_joined')
    return render(request, 'admins/admin_users.html', {
        'users': users,
    })