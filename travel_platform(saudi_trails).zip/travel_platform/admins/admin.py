from django.contrib import admin
from .models import AdminProfile

class AdminProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'department')
    search_fields = ('user__username', 'department')

admin.site.register(AdminProfile, AdminProfileAdmin)