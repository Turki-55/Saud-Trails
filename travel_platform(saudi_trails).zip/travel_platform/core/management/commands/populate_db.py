import random
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from core.models import (
    Destination, Event, Review, Booking, 
    Payment, RefundRequest, SupportTicket
)
from tourists.models import TouristProfile, TouristTravelHistory
from freelancers.models import FreelancerProfile, FreelancerService
from admins.models import AdminProfile

# Get the custom User model
User = get_user_model()

class Command(BaseCommand):
    help = 'Populates the database with comprehensive sample data using realistic Arabic names'

    def handle(self, *args, **options):
        self.stdout.write("Starting database population with realistic data...")
        
        # Clear existing data first to avoid conflicts
        self.clear_all_data()
        
        # Create users with Arabic names first as other models depend on them
        self.create_users_with_arabic_names()
        
        # Create destinations with Saudi locations
        destinations = self.create_saudi_destinations()
        
        # Create events at these destinations
        events = self.create_events_at_destinations(destinations)
        
        # Create freelancer profiles with Arabic bios
        self.create_arabic_freelancers()
        
        # Create tourist profiles
        self.create_tourists_with_history(destinations)
        
        # Create admin profiles
        self.create_admin_profiles()
        
        # Create bookings
        bookings = self.create_realistic_bookings(destinations, events)
        
        # Create reviews in Arabic and English
        self.create_multilingual_reviews(destinations, events)
        
        # Create payments
        self.create_payment_records(bookings)
        
        # Create refund requests
        self.create_refund_requests(bookings)
        
        # Create support tickets
        self.create_support_tickets()
        
        self.stdout.write(self.style.SUCCESS('Successfully populated database with realistic Saudi travel data!'))

    def clear_all_data(self):
        """Clear all data from relevant models"""
        models = [
            TouristTravelHistory, TouristProfile,
            FreelancerService, FreelancerProfile,
            AdminProfile,
            SupportTicket, RefundRequest, Payment,
            Booking, Review, Event, Destination,
            User
        ]
        
        # Delete in reverse order to avoid foreign key constraints
        for model in reversed(models):
            model.objects.all().delete()
            self.stdout.write(f"Cleared all {model.__name__} data")
        
        self.stdout.write("All data cleared successfully")

    def create_users_with_arabic_names(self):
        """Create users with authentic Arabic names and Saudi details"""
        user_data = [
            # Admins (typically Arabic names)
            {'username': 'ahmed_admin', 'email': 'ahmed.alghamdi@example.sa', 'password': 'Admin@1234', 
             'first_name': 'أحمد', 'last_name': 'الغامدي', 'user_type': 'admin'},
            {'username': 'sara_admin', 'email': 'sara.alqurashi@example.sa', 'password': 'Admin@1234', 
             'first_name': 'سارة', 'last_name': 'القرشي', 'user_type': 'admin'},
            
            # Freelancers (guides, drivers, etc.)
            {'username': 'yousef_guide', 'email': 'yousef.almansour@example.sa', 'password': 'Guide@1234', 
             'first_name': 'يوسف', 'last_name': 'المنصور', 'user_type': 'freelancer'},
            {'username': 'khalid_driver', 'email': 'khalid.alrashid@example.sa', 'password': 'Driver@1234', 
             'first_name': 'خالد', 'last_name': 'الراشد', 'user_type': 'freelancer'},
            {'username': 'leena_photo', 'email': 'leena.alsulaiman@example.sa', 'password': 'Photo@1234', 
             'first_name': 'لينا', 'last_name': 'السليمان', 'user_type': 'freelancer'},
            
            # Tourists (mix of Arabic and international names)
            {'username': 'mohammed_traveler', 'email': 'mohammed.alotaibi@example.sa', 'password': 'Travel@1234', 
             'first_name': 'محمد', 'last_name': 'العتيبي', 'user_type': 'tourist'},
            {'username': 'fatima_explorer', 'email': 'fatima.alharbi@example.sa', 'password': 'Explore@1234', 
             'first_name': 'فاطمة', 'last_name': 'الحربي', 'user_type': 'tourist'},
            {'username': 'nora_visitor', 'email': 'nora.alshehri@example.sa', 'password': 'Visit@1234', 
             'first_name': 'نورة', 'last_name': 'الشهري', 'user_type': 'tourist'},
            {'username': 'james_visitor', 'email': 'james.wilson@example.com', 'password': 'Visit@1234', 
             'first_name': 'James', 'last_name': 'Wilson', 'user_type': 'tourist'},
            {'username': 'linda_tourist', 'email': 'linda.chen@example.com', 'password': 'Tourist@1234', 
             'first_name': 'Linda', 'last_name': 'Chen', 'user_type': 'tourist'},
        ]
        
        for data in user_data:
            user = User.objects.create_user(
                username=data['username'],
                email=data['email'],
                password=data['password'],
                user_type=data['user_type'],
                first_name=data.get('first_name', ''),
                last_name=data.get('last_name', '')
            )
            
            # Set Saudi-specific details
            user.phone_number = f'9665{random.randint(10000000, 99999999)}'
            user.address = self.generate_saudi_address()
            user.save()
        
        self.stdout.write(f"Created {len(user_data)} realistic users with Arabic names")

    def generate_saudi_address(self):
        """Generate realistic Saudi addresses"""
        cities = ['الرياض', 'جدة', 'مكة المكرمة', 'المدينة المنورة', 'الدمام']
        districts = {
            'الرياض': ['المربع', 'الملز', 'النخيل', 'الغرير', 'العليا'],
            'جدة': ['البغدادية', 'الصفا', 'الروضة', 'الكورنيش', 'الزهراء'],
            'مكة المكرمة': ['العزيزية', 'الشبيكة', 'الجموم', 'الزاهر', 'الشرائع'],
            'المدينة المنورة': ['العنبرية', 'السيح', 'الخالدية', 'المناخة', 'قباء'],
            'الدمام': ['النهضة', 'الخليج', 'الروضة', 'المنتزه', 'السوق']
        }
        city = random.choice(cities)
        district = random.choice(districts[city])
        street = random.choice(['شارع الملك فهد', 'شارع التحلية', 'شارع الأمير محمد', 'شارع العليا العام', 'شارع الستين'])
        building = random.randint(1, 500)
        return f"{building} {street}، حي {district}، {city}، المملكة العربية السعودية"

    def create_saudi_destinations(self):
        """Create authentic Saudi destinations"""
        destinations = [
            {
                'name': 'العلا',
                'name_en': 'Al-Ula',
                'location': 'منطقة المدينة المنورة',
                'description': 'موقع أثري قديم بتشكيلات صخرية مذهلة ومناطق تراثية',
                'description_en': 'Ancient archaeological site with stunning rock formations and heritage areas',
                'price_per_person': 250.00,
                'is_approved': True
            },
            {
                'name': 'واحة الأحساء',
                'name_en': 'Al-Ahsa Oasis',
                'location': 'المنطقة الشرقية',
                'description': 'أكبر واحة نخيل في العالم وموقع تراث عالمي لليونسكو',
                'description_en': 'World\'s largest palm oasis and UNESCO World Heritage site',
                'price_per_person': 180.00,
                'is_approved': True
            },
            {
                'name': 'جبل الفهدة',
                'name_en': 'Edge of the World',
                'location': 'جبل الفهدة، الرياض',
                'description': 'منحدرات صخرية شاهقة تطل على أفق خلاب',
                'description_en': 'Towering cliffs overlooking a breathtaking horizon',
                'price_per_person': 120.00,
                'is_approved': True
            },
            {
                'name': 'بلد جدة التاريخية',
                'name_en': 'Historic Jeddah',
                'location': 'جدة',
                'description': 'منطقة تراثية ببيوت خشبية تقليدية ومساجد تاريخية',
                'description_en': 'Heritage area with traditional wooden houses and historic mosques',
                'price_per_person': 90.00,
                'is_approved': True
            },
        ]
        
        created_destinations = []
        admin_user = User.objects.filter(user_type='admin').first()
        
        for dest in destinations:
            destination = Destination.objects.create(
                name=dest['name'],
                location=dest['location'],
                description=dest['description'],
                price_per_person=dest['price_per_person'],
                is_approved=dest['is_approved'],
                suggested_by=admin_user
            )
            created_destinations.append(destination)
        
        self.stdout.write(f"Created {len(created_destinations)} authentic Saudi destinations")
        return created_destinations

    def create_events_at_destinations(self, destinations):
        """Create culturally relevant events at destinations"""
        events = []
        guide = User.objects.get(username='yousef_guide')
        photographer = User.objects.get(username='leena_photo')
        
        arabic_event_titles = [
            "جولة تاريخية في العلا",
            "رحلة سفاري في الربع الخالي",
            "زيارة الأسواق الشعبية",
            "تجربة المطبخ السعودي",
            "جولة تصوير الأماكن التراثية"
        ]
        
        english_event_titles = [
            "Historical Tour of Al-Ula",
            "Rub' al Khali Safari",
            "Traditional Markets Visit",
            "Saudi Cuisine Experience",
            "Heritage Photography Tour"
        ]
        
        arabic_descriptions = [
            "جولة بصحبة مرشد سياحي متخصص في تاريخ المنطقة",
            "مغامرة سفاري في الصحراء مع مرشدين محترفين",
            "تجربة التسوق في الأسواق التقليدية مع شرح للمنتجات",
            "تعلم طهي الأطباق السعودية مع طهاة محليين",
            "جولة تصوير للمعالم التراثية مع مصور محترف"
        ]
        
        english_descriptions = [
            "Tour with a specialized guide in the region's history",
            "Desert safari adventure with professional guides",
            "Traditional market shopping experience with product explanations",
            "Learn to cook Saudi dishes with local chefs",
            "Photography tour of heritage sites with professional photographer"
        ]
        
        for i, dest in enumerate(destinations):
            # Alternate between Arabic and English events
            if i % 2 == 0:
                title = arabic_event_titles[i % len(arabic_event_titles)]
                description = arabic_descriptions[i % len(arabic_descriptions)]
            else:
                title = english_event_titles[i % len(english_event_titles)]
                description = english_descriptions[i % len(english_descriptions)]
            
            # Alternate between guide and photographer
            creator = guide if i % 2 == 0 else photographer
            
            event_data = {
                'title': title,
                'destination': dest,
                'date': datetime.now() + timedelta(days=7+i),
                'time': datetime.strptime(f'{9+i}:00', '%H:%M').time(),
                'description': description,
                'price': dest.price_per_person * (1 + (i * 0.3)),  # 30% increase for each subsequent event
                'capacity': 10 + (i * 3),
                'created_by': creator
            }
            event = Event.objects.create(**event_data)
            events.append(event)
        
        self.stdout.write(f"Created {len(events)} culturally relevant events")
        return events

    def create_arabic_freelancers(self):
        """Create freelancer profiles with Arabic details"""
        freelancers = [
            {
                'user': User.objects.get(username='yousef_guide'),
                'bio': "مرشد سياحي معتمد بخبرة ٧ سنوات في السياحة التراثية بالمملكة",
                'skills': "تاريخ المملكة، التراث الثقافي، اللغات",
                'experience': 7,
                'languages': "العربية، الإنجليزية، الفرنسية"
            },
            {
                'user': User.objects.get(username='khalid_driver'),
                'bio': "سائق محترف بخبرة ١٠ سنوات في القيادة الصحراوية والطرق الوعرة",
                'skills': "الملاحة الصحراوية، صيانة السيارات، السلامة",
                'experience': 10,
                'languages': "العربية، الإنجليزية"
            },
            {
                'user': User.objects.get(username='leena_photo'),
                'bio': "مصورة محترفة متخصصة في التصوير السياحي والتراثي",
                'skills': "تصوير الأماكن، البورتريه، التصوير الجوي",
                'experience': 5,
                'languages': "العربية، الإنجليزية، الألمانية"
            }
        ]
        
        arabic_services = [
            {'service_type': 'guide', 'title': 'جولة المدينة', 'description': 'جولة نصف يومية في المعالم الرئيسية', 'price': 200.00},
            {'service_type': 'guide', 'title': 'جولة المواقع التاريخية', 'description': 'جولة يوم كامل في المواقع التاريخية', 'price': 350.00},
            {'service_type': 'transport', 'title': 'نقل من المطار', 'description': 'سيارة مريحة لنقل الركاب من المطار', 'price': 150.00},
            {'service_type': 'photography', 'title': 'جلسة تصوير', 'description': 'جلسة تصوير احترافية لمدة ساعة', 'price': 250.00},
            {'service_type': 'event', 'title': 'تخطيط الفعاليات', 'description': 'خدمة تخطيط فعاليات مخصصة', 'price': 400.00},
        ]
        
        for freelancer in freelancers:
            profile, created = FreelancerProfile.objects.get_or_create(
                user=freelancer['user'],
                defaults={
                    'bio': freelancer['bio'],
                    'skills': freelancer['skills'],
                    'experience': freelancer['experience'],
                    'languages': freelancer['languages']
                }
            )
            
            # Assign 2-3 services per freelancer
            for service in random.sample(arabic_services, random.randint(2, 3)):
                FreelancerService.objects.create(
                    freelancer=freelancer['user'],
                    **service,
                    is_available=True,
                    is_approved=True
                )
        
        self.stdout.write("Created freelancer profiles with authentic Arabic details")

    def create_tourists_with_history(self, destinations):
        """Create tourist profiles with travel history"""
        arabic_preferences = [
            "التراث الثقافي",
            "المغامرات",
            "الاسترخاء",
            "التسوق",
            "التصوير"
        ]
        
        english_preferences = [
            "Cultural Heritage",
            "Adventure",
            "Relaxation",
            "Shopping",
            "Photography"
        ]
        
        arabic_notes = [
            "استمتعت بالمناظر الطبيعية الخلابة",
            "التجربة الثقافية كانت رائعة",
            "الطعام المحلي كان لذيذًا",
            "المرشد السياحي كان على قدر عال من المعرفة",
            "سأعود مرة أخرى بالتأكيد"
        ]
        
        english_notes = [
            "Enjoyed the breathtaking landscapes",
            "The cultural experience was amazing",
            "The local food was delicious",
            "The tour guide was very knowledgeable",
            "I will definitely come back again"
        ]
        
        for user in User.objects.filter(user_type='tourist'):
            # Determine if Arabic or English profile
            if any(c.isascii() for c in user.first_name):  # English name
                preferences = random.choice(english_preferences)
                notes = random.choice(english_notes)
            else:  # Arabic name
                preferences = random.choice(arabic_preferences)
                notes = random.choice(arabic_notes)
            
            # Get or create the profile
            profile, created = TouristProfile.objects.get_or_create(
                user=user,
                defaults={'preferences': preferences}
            )
            
            # If profile already existed, update preferences
            if not created:
                profile.preferences = preferences
                profile.save()
            
            # Add travel history for 60% of tourists
            if random.random() < 0.6:
                for dest in random.sample(destinations, random.randint(1, 3)):
                    visited_date = datetime.now() - timedelta(days=random.randint(30, 365))
                    
                    TouristTravelHistory.objects.create(
                        tourist=profile,
                        destination=dest,
                        visited_date=visited_date,
                        notes=notes
                    )
        
        self.stdout.write("Created tourist profiles with travel history")

    def create_admin_profiles(self):
        """Create admin profiles with Saudi departments"""
        departments = [
            "إدارة العمليات",
            "خدمة العملاء",
            "التسويق",
            "الشؤون المالية",
            "تطوير الأعمال"
        ]
        
        for user in User.objects.filter(user_type='admin'):
            AdminProfile.objects.get_or_create(
                user=user,
                defaults={'department': random.choice(departments)}
            )
        
        self.stdout.write("Created admin profiles with Saudi departments")

    def create_realistic_bookings(self, destinations, events):
        """Create realistic bookings with Arabic details"""
        bookings = []
        tourists = User.objects.filter(user_type='tourist')
        freelancers = User.objects.filter(user_type='freelancer')
        statuses = ['pending', 'confirmed', 'completed', 'cancelled']
        
        arabic_requests = [
            "أحتاج إلى وجبات نباتية",
            "مطلوب مكان مناسب لذوي الاحتياجات الخاصة",
            "أفضل المواعيد الصباحية",
            "هل يوجد مرشد يتحدث الفرنسية؟",
            "أريد حجز سائق خاص"
        ]
        
        english_requests = [
            "Need vegetarian meals",
            "Require wheelchair accessible facilities",
            "Prefer morning schedule",
            "Is there a French-speaking guide?",
            "I want to book a private driver"
        ]
        
        for i, tourist in enumerate(tourists):
            # Determine if Arabic or English booking
            is_arabic = not any(c.isascii() for c in tourist.first_name)
            
            # Alternate between destination and event bookings
            if i % 2 == 0:
                booking_type = 'destination'
                destination = random.choice(destinations)
                event = None
                price = destination.price_per_person * random.randint(1, 4)
            else:
                booking_type = 'event'
                event = random.choice(events)
                destination = None
                price = event.price * random.randint(1, 2)
            
            # Create booking
            booking = Booking.objects.create(
                tourist=tourist,
                destination=destination,
                event=event,
                freelancer=random.choice(freelancers) if random.choice([True, False]) else None,
                start_date=datetime.now() + timedelta(days=random.randint(1, 30)),
                end_date=datetime.now() + timedelta(days=random.randint(2, 35)),
                number_of_people=random.randint(1, 4),
                total_price=price,
                status=random.choice(statuses),
                special_requests=random.choice(arabic_requests if is_arabic else english_requests),
                is_paid=random.choice([True, False])
            )
            bookings.append(booking)
        
        self.stdout.write(f"Created {len(bookings)} realistic bookings")
        return bookings

    def create_multilingual_reviews(self, destinations, events):
        """Create reviews in both Arabic and English"""
        arabic_comments = [
            "تجربة رائعة وممتعة جداً",
            "المرشد السياحي كان محترفاً ومطلعاً",
            "الموقع جميل ويستحق الزيارة",
            "الخدمة كانت ممتازة والطاقم ودود",
            "سعر مناسب مقابل ما تم تقديمه"
        ]
        
        english_comments = [
            "Amazing and very enjoyable experience",
            "The tour guide was professional and knowledgeable",
            "Beautiful location worth visiting",
            "Excellent service with friendly staff",
            "Reasonable price for what was offered"
        ]
        
        for i in range(15):  # Create 15 reviews
            # Choose random reviewer
            reviewer = random.choice(User.objects.filter(user_type='tourist'))
            is_arabic = not any(c.isascii() for c in reviewer.first_name)
            
            # Randomly choose what to review
            review_type = random.choice(['destination', 'event', 'freelancer'])
            
            review_data = {
                'reviewer': reviewer,
                'rating': random.randint(3, 5),
                'comment': random.choice(arabic_comments if is_arabic else english_comments),
                'is_approved': True
            }
            
            if review_type == 'destination':
                review_data['destination'] = random.choice(destinations)
            elif review_type == 'event':
                review_data['event'] = random.choice(events)
            else:
                review_data['freelancer'] = random.choice(User.objects.filter(user_type='freelancer'))
            
            Review.objects.create(**review_data)
        
        self.stdout.write("Created 15 multilingual reviews (Arabic and English)")

    def create_payment_records(self, bookings):
        """Create payment records with Saudi payment methods"""
        arabic_methods = [
            "الدفع بالبطاقة",
            "حوالة بنكية",
            "الدفع عند الوصول",
            "حساب سداد"
        ]
        
        english_methods = [
            "Credit Card",
            "Bank Transfer",
            "Pay on Arrival",
            "Sadad Account"
        ]
        
        for booking in bookings:
            is_arabic = not any(c.isascii() for c in booking.tourist.first_name)
            
            if booking.is_paid:
                Payment.objects.create(
                    booking=booking,
                    amount=booking.total_price,
                    payment_method=random.choice(arabic_methods if is_arabic else english_methods),
                    transaction_id=f"TXN{random.randint(100000, 999999)}",
                    status='completed'
                )
            elif random.choice([True, False]):
                Payment.objects.create(
                    booking=booking,
                    amount=booking.total_price * random.uniform(0.1, 0.9),  # Partial payment
                    payment_method=random.choice(arabic_methods if is_arabic else english_methods),
                    transaction_id=f"TXN{random.randint(100000, 999999)}",
                    status=random.choice(['pending', 'failed'])
                )
        
        self.stdout.write("Created payment records with Saudi payment methods")

    def create_refund_requests(self, bookings):
        """Create refund requests with Arabic/English reasons"""
        arabic_reasons = [
            "تغيير في الخطط",
            "وجدت خياراً أفضل",
            "ظروف طارئة",
            "عدم الرضا عن الخدمة",
            "تأخر في تقديم الخدمة"
        ]
        
        english_reasons = [
            "Change of plans",
            "Found a better option",
            "Unexpected circumstances",
            "Dissatisfied with service",
            "Service delay"
        ]
        
        cancelled_bookings = [b for b in bookings if b.status == 'cancelled']
        
        for booking in random.sample(cancelled_bookings, min(3, len(cancelled_bookings))):
            is_arabic = not any(c.isascii() for c in booking.tourist.first_name)
            
            RefundRequest.objects.create(
                booking=booking,
                tourist=booking.tourist,
                reason=random.choice(arabic_reasons if is_arabic else english_reasons),
                status=random.choice(['pending', 'approved', 'rejected'])
            )
        
        self.stdout.write("Created refund requests with Arabic/English reasons")

    def create_support_tickets(self):
        """Create support tickets in Arabic and English"""
        arabic_subjects = [
            "تعديل الحجز",
            "مشكلة في الدفع",
            "طلب خاص",
            "استفسار عن الإلغاء",
            "ملاحظات أو شكوى"
        ]
        
        arabic_messages = [
            "أحتاج إلى تعديل في تفاصيل حجزي",
            "واجهت مشكلة أثناء عملية الدفع",
            "لدي طلب خاص يتعلق بخدماتكم",
            "أريد الاستفسار عن سياسة الإلغاء",
            "أود تقديم ملاحظاتي حول الخدمة"
        ]
        
        english_subjects = [
            "Booking Modification",
            "Payment Issue",
            "Special Request",
            "Cancellation Inquiry",
            "Feedback"
        ]
        
        english_messages = [
            "I need to modify my booking details",
            "I encountered an issue during payment",
            "I have a special request regarding your services",
            "I want to inquire about cancellation policy",
            "I would like to provide feedback about the service"
        ]
        
        for i in range(8):  # Create 8 tickets
            user = random.choice(User.objects.all())
            is_arabic = not any(c.isascii() for c in user.first_name)
            
            if is_arabic:
                subject = random.choice(arabic_subjects)
                message = random.choice(arabic_messages)
            else:
                subject = random.choice(english_subjects)
                message = random.choice(english_messages)
            
            SupportTicket.objects.create(
                user=user,
                subject=subject,
                message=message,
                status=random.choice(['open', 'in_progress', 'resolved'])
            )
        
        self.stdout.write("Created support tickets in Arabic and English")