from django.contrib import admin
from .models import (
    User, Destination, Event, 
    Review, Booking, Payment,
    RefundRequest, SupportTicket
)

# Custom User Admin
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'user_type', 'is_staff')
    list_filter = ('user_type', 'is_staff')
    search_fields = ('username', 'email')

# Register other core models
class DestinationAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'price_per_person', 'is_approved')
    list_filter = ('is_approved',)
    search_fields = ('name', 'location')

class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'destination', 'date', 'price')
    list_filter = ('destination',)
    search_fields = ('title', 'description')

class BookingAdmin(admin.ModelAdmin):
    list_display = ('tourist', 'destination', 'status', 'start_date')
    list_filter = ('status', 'destination')
    search_fields = ('tourist__username',)

# Register all core models
admin.site.register(User, UserAdmin)
admin.site.register(Destination, DestinationAdmin)
admin.site.register(Event, EventAdmin)
admin.site.register(Review)
admin.site.register(Booking, BookingAdmin)
admin.site.register(Payment)
admin.site.register(RefundRequest)
admin.site.register(SupportTicket)