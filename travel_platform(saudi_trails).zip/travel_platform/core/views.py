# core/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegistrationForm, UserTypeForm
from django.contrib.auth import logout  # Add this import at the top
from django.shortcuts import render
from core.models import Destination  # Make sure to import your Destination model

def home(request):
    # Get 3 most popular destinations (you can adjust the criteria)
    popular_destinations = Destination.objects.filter(is_approved=True).order_by('-created_at')[:3]
    
    context = {
        'popular_destinations': popular_destinations
    }
    return render(request, 'core/home.html', context)
def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        type_form = UserTypeForm(request.POST)
        
        if user_form.is_valid() and type_form.is_valid():
            user = user_form.save(commit=False)
            user.user_type = type_form.cleaned_data['user_type']
            user.save()
            
            login(request, user)
            return redirect('profile_redirect')
    else:
        user_form = UserRegistrationForm()
        type_form = UserTypeForm()
    
    return render(request, 'core/register.html', {
        'user_form': user_form,
        'type_form': type_form,
    })

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile_redirect')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

@login_required
def profile_redirect(request):
    if request.user.user_type == 'tourist':
        return redirect('tourist_dashboard')
    elif request.user.user_type == 'freelancer':
        return redirect('freelancer_dashboard')
    elif request.user.user_type == 'admin':
        return redirect('admin_dashboard')
    else:
        return redirect('home')
from django.contrib.auth import logout
from django.shortcuts import redirect

from django.contrib.auth import logout
from django.shortcuts import redirect

def user_logout(request):
    logout(request)
    # Add this to prevent admin logout template from appearing
    request.session['logout_from_site'] = True
    return redirect('home')