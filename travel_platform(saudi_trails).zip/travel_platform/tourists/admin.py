from django.contrib import admin
from .models import TouristProfile, TouristTravelHistory

class TouristProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'preferences')
    search_fields = ('user__username',)

class TouristTravelHistoryAdmin(admin.ModelAdmin):
    list_display = ('tourist', 'destination', 'visited_date')
    list_filter = ('destination',)
    search_fields = ('tourist__user__username',)

admin.site.register(TouristProfile, TouristProfileAdmin)
admin.site.register(TouristTravelHistory, TouristTravelHistoryAdmin)