from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.tourist_dashboard, name='tourist_dashboard'),
    path('search/', views.search_filter, name='search_filter'),
    path('request-freelancer/<int:service_id>/', views.request_freelancer, name='request_freelancer'),
    path('cancel-request/<int:booking_id>/', views.cancel_request, name='cancel_request'),
    path('post-review/<str:model_type>/<int:model_id>/', views.post_review, name='post_review'),
    path('view-history/', views.view_history, name='view_history'),
    path('suggest-destination/', views.suggest_destination, name='suggest_destination'),
    path('book/<str:item_type>/<int:item_id>/', views.book_request, name='book_request'),
    path('request-refund/<int:booking_id>/', views.request_refund, name='request_refund'),
    path('redeem-points/', views.redeem_points, name='redeem_points'),
    path('estimate-budget/', views.estimate_budget, name='estimate_budget'),
    path('pay-bill/<int:booking_id>/', views.pay_bill, name='pay_bill'),
    path('reviews/<str:model_type>/<int:model_id>/', views.display_reviews, name='display_reviews'),
    path('booking-history/', views.booking_history, name='tourist_booking_history'),
    path('contact-support/', views.contact_support, name='contact_support'),
    path('booking/<int:booking_id>/', views.booking_detail, name='booking_detail'),
    path('booking/<int:booking_id>/payment-confirmation/', views.payment_confirmation, name='payment_confirmation'),

]