from django.db import models
from core.models import User, Destination, Event, Booking

class TouristProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    preferences = models.TextField(blank=True)
    travel_history = models.ManyToManyField(Destination, through='TouristTravelHistory', blank=True)
    
    def __str__(self):
        return f"Profile of {self.user.username}"

class TouristTravelHistory(models.Model):
    tourist = models.ForeignKey(TouristProfile, on_delete=models.CASCADE)
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE)
    visited_date = models.DateField()
    notes = models.TextField(blank=True)
    
    def __str__(self):
        return f"{self.tourist.user.username} visited {self.destination.name} on {self.visited_date}"