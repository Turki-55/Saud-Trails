from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from freelancers.models import FreelancerService
from core.models import Destination, Event, Booking, Review, RefundRequest, SupportTicket,Payment
from tourists.models import TouristProfile
from tourists.forms import DestinationSuggestionForm, BookingForm, ReviewForm, RefundRequestForm, SupportTicketForm
from django.db.models import Q
from datetime import date
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

@login_required
def tourist_dashboard(request):
    if request.user.user_type != 'tourist':
        return redirect('profile_redirect')
    
    try:
        profile = request.user.touristprofile
    except TouristProfile.DoesNotExist:
        profile = TouristProfile.objects.create(user=request.user)
    
    upcoming_bookings = Booking.objects.filter(
        tourist=request.user, 
        status__in=['confirmed', 'pending'],
        start_date__gte=date.today()
    ).order_by('start_date')[:5]
    
    recent_destinations = Destination.objects.filter(
        is_approved=True
    ).order_by('-created_at')[:5]
    
    return render(request, 'tourists/dashboard.html', {
        'profile': profile,
        'upcoming_bookings': upcoming_bookings,
        'recent_destinations': recent_destinations,
    })
@login_required
def search_filter(request):
    query = request.GET.get('q', '')
    location = request.GET.get('location', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    
    destinations = Destination.objects.filter(is_approved=True)
    events = Event.objects.all()
    freelancers = User.objects.filter(user_type='freelancer')
    services = FreelancerService.objects.filter(is_available=True, is_approved=True)
    
    if query:
        destinations = destinations.filter(
            Q(name__icontains=query) | 
            Q(description__icontains=query) |
            Q(location__icontains=query)
        )
        events = events.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query)
        )
        freelancers = freelancers.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query)
        )
        services = services.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query)
        )
    
    if location:
        destinations = destinations.filter(location__icontains=location)
        events = events.filter(destination__location__icontains=location)
    
    if min_price:
        destinations = destinations.filter(price_per_person__gte=min_price)
        events = events.filter(price__gte=min_price)
        services = services.filter(price__gte=min_price)
    
    if max_price:
        destinations = destinations.filter(price_per_person__lte=max_price)
        events = events.filter(price__lte=max_price)
        services = services.filter(price__lte=max_price)
    
    return render(request, 'tourists/search_filter.html', {
        'destinations': destinations,
        'events': events,
        'freelancers': freelancers,
        'services': services,
        'query': query,
        'location': location,
        'min_price': min_price,
        'max_price': max_price,
    })
@login_required
def request_freelancer(request, service_id):
    service = get_object_or_404(FreelancerService, id=service_id, is_available=True, is_approved=True)
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.tourist = request.user
            booking.freelancer = service.freelancer
            booking.total_price = service.price * booking.number_of_people
            booking.status = 'pending'
            booking.save()
            
            messages.success(request, 'Your booking request has been sent to the freelancer.')
            return redirect('tourist_dashboard')
    else:
        form = BookingForm(initial={
            'start_date': date.today(),
            'end_date': date.today(),
            'number_of_people': 1,
        })
    
    return render(request, 'tourists/request_freelancer.html', {
        'service': service,
        'form': form,
    })

@login_required
def cancel_request(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, tourist=request.user)
    
    if booking.status in ['pending', 'confirmed']:
        booking.status = 'cancelled'
        booking.save()
        messages.success(request, 'Your booking has been cancelled.')
    else:
        messages.error(request, 'This booking cannot be cancelled.')
    
    return redirect('tourist_booking_history')
@login_required
def post_review(request, model_type, model_id):
    model_map = {
        'destination': Destination,
        'event': Event,
        'freelancer': get_user_model(),
    }
    
    ModelClass = model_map.get(model_type)
    if not ModelClass:
        return redirect('tourist_dashboard')
    
    item = get_object_or_404(ModelClass, id=model_id)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.reviewer = request.user
            review.is_approved = True  # Auto-approve reviews
            
            # Clear other relationships before setting the correct one
            review.destination = None
            review.event = None
            review.freelancer = None
            
            if model_type == 'destination':
                review.destination = item
            elif model_type == 'event':
                review.event = item
            elif model_type == 'freelancer':
                review.freelancer = item
            
            review.save()
            messages.success(request, 'Thank you for your review!')
            return redirect('display_reviews', model_type=model_type, model_id=model_id)
    else:
        form = ReviewForm()
    
    return render(request, 'tourists/post_review.html', {
        'form': form,
        'item': item,
        'model_type': model_type,
    })
@login_required
def view_history(request):
    profile = get_object_or_404(TouristProfile, user=request.user)
    travel_history = profile.travel_history.all()
    return render(request, 'tourists/view_history.html', {
        'travel_history': travel_history,
    })

@login_required
def suggest_destination(request):
    if request.method == 'POST':
        form = DestinationSuggestionForm(request.POST, request.FILES)
        if form.is_valid():
            destination = form.save(commit=False)
            destination.suggested_by = request.user
            destination.is_approved = False
            destination.save()
            messages.success(request, 'Thank you for your suggestion! It will be reviewed by our team.')
            return redirect('tourist_dashboard')
    else:
        form = DestinationSuggestionForm()
    
    return render(request, 'tourists/suggest_destination.html', {
        'form': form,
    })

@login_required
def book_request(request, item_type, item_id):
    if item_type == 'destination':
        item = get_object_or_404(Destination, id=item_id, is_approved=True)
    elif item_type == 'event':
        item = get_object_or_404(Event, id=item_id)
    else:
        return redirect('tourist_dashboard')
    
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.tourist = request.user
            
            if item_type == 'destination':
                booking.destination = item
                booking.total_price = item.price_per_person * booking.number_of_people
            elif item_type == 'event':
                booking.event = item
                booking.total_price = item.price * booking.number_of_people
            
            booking.status = 'pending'
            booking.save()
            
            messages.success(request, 'Your booking request has been submitted!')
            return redirect('tourist_booking_history')
    else:
        form = BookingForm(initial={
            'start_date': date.today(),
            'end_date': date.today(),
            'number_of_people': 1,
        })
    
    return render(request, 'tourists/book_request.html', {
        'item': item,
        'item_type': item_type,
        'form': form,
    })

@login_required
def request_refund(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, tourist=request.user)
    
    if request.method == 'POST':
        form = RefundRequestForm(request.POST)
        if form.is_valid():
            refund_request = form.save(commit=False)
            refund_request.booking = booking
            refund_request.tourist = request.user
            refund_request.save()
            
            messages.success(request, 'Your refund request has been submitted for review.')
            return redirect('tourist_booking_history')
    else:
        form = RefundRequestForm()
    
    return render(request, 'tourists/request_refund.html', {
        'booking': booking,
        'form': form,
    })

@login_required
def redeem_points(request):
    if request.method == 'POST':
        points_to_redeem = int(request.POST.get('points', 0))
        
        if points_to_redeem <= request.user.loyalty_points:
            request.user.loyalty_points -= points_to_redeem
            request.user.save()
            messages.success(request, f'You have successfully redeemed {points_to_redeem} points.')
        else:
            messages.error(request, 'You do not have enough points to redeem.')
        
        return redirect('tourist_dashboard')
    
    return render(request, 'tourists/redeem_points.html')

@login_required
def estimate_budget(request):
    if request.method == 'POST':
        destination_id = request.POST.get('destination')
        num_people = int(request.POST.get('num_people', 1))
        num_days = int(request.POST.get('num_days', 1))
        
        destination = get_object_or_404(Destination, id=destination_id)
        base_cost = destination.price_per_person * num_people * num_days
        
        # Additional estimates (simplified)
        accommodation = 50 * num_people * num_days  # $50 per person per day
        food = 30 * num_people * num_days  # $30 per person per day
        transportation = 20 * num_people * num_days  # $20 per person per day
        
        total_estimate = base_cost + accommodation + food + transportation
        
        return render(request, 'tourists/estimate_budget_result.html', {
            'destination': destination,
            'num_people': num_people,
            'num_days': num_days,
            'base_cost': base_cost,
            'accommodation': accommodation,
            'food': food,
            'transportation': transportation,
            'total_estimate': total_estimate,
        })
    
    destinations = Destination.objects.filter(is_approved=True)
    return render(request, 'tourists/estimate_budget.html', {
        'destinations': destinations,
    })

@login_required
def pay_bill(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, tourist=request.user)
    
    if request.method == 'POST':
        # In a real app, this would integrate with a payment gateway
        booking.is_paid = True
        booking.save()
        
        # Add loyalty points (10 points per $100 spent)
        points_earned = int(booking.total_price / 100) * 10
        request.user.loyalty_points += points_earned
        request.user.save()
        
        messages.success(request, f'Payment successful! You earned {points_earned} loyalty points.')
        return redirect('tourist_booking_history')
    
    return render(request, 'tourists/pay_bill.html', {
        'booking': booking,
    })

@login_required
def display_reviews(request, model_type, model_id):
    model_map = {
        'destination': Destination,
        'event': Event,
        'freelancer': User,
    }
    
    ModelClass = model_map.get(model_type)
    if not ModelClass:
        return redirect('tourist_dashboard')
    
    item = get_object_or_404(ModelClass, id=model_id)
    
    if model_type == 'destination':
        reviews = Review.objects.filter(destination=item, is_approved=True)
    elif model_type == 'event':
        reviews = Review.objects.filter(event=item, is_approved=True)
    elif model_type == 'freelancer':
        reviews = Review.objects.filter(freelancer=item, is_approved=True)
    
    return render(request, 'tourists/display_reviews.html', {
        'item': item,
        'reviews': reviews,
        'model_type': model_type,
    })

@login_required
def booking_history(request):
    bookings = Booking.objects.filter(tourist=request.user).order_by('-created_at')
    return render(request, 'tourists/booking_history.html', {
        'bookings': bookings,
    })

@login_required
def contact_support(request):
    if request.method == 'POST':
        form = SupportTicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.user = request.user
            ticket.save()
            messages.success(request, 'Your support ticket has been submitted. We will get back to you soon.')
            return redirect('tourist_dashboard')
    else:
        form = SupportTicketForm()
    
    return render(request, 'tourists/contact_support.html', {
        'form': form,
    })
@login_required
def booking_detail(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, tourist=request.user)
    
    if request.method == 'POST' and 'pay_now' in request.POST:
        # Mark booking as paid
        booking.is_paid = True
        booking.save()
        
        # Create a payment record
        from core.models import Payment
        payment = Payment.objects.create(
            booking=booking,
            amount=booking.total_price,
            payment_method='Manual',
            transaction_id=f'MANUAL-{booking.id}-{timezone.now().timestamp()}',
            status='completed'
        )
        
        # Add loyalty points (10 points per $100 spent)
        points_earned = int(booking.total_price / 100) * 10
        request.user.loyalty_points += points_earned
        request.user.save()
        
        return redirect('payment_confirmation', booking_id=booking.id)
    
    return render(request, 'tourists/booking_detail.html', {
        'booking': booking,
    })

@login_required
def payment_confirmation(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, tourist=request.user)
    payment = Payment.objects.filter(booking=booking).first()
    
    return render(request, 'tourists/payment_confirmation.html', {
        'booking': booking,
        'payment': payment,
    })